import './App.css';
import React, { useEffect, useState } from 'react';
import Header from './Header';
import Footer from './Footer';
import Product from './Product';

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch('https://dummyjson.com/products');
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleProductDelete = (productId) => {
    const updateProducts = products.filter((product) => product.id !== productId);
    setProducts(updateProducts);
    localStorage.setItem('productss', JSON.stringify(updateProducts));
  };

  return (
    <div className='App'>
      <Header />
      <div className='products-grid'>
        {products.map((product) => (
          <Product
          key={product.id}
          product={product}
          onDelete={handleProductDelete}
          />
        ))}
      </div>
      <Footer />
    </div>
  );
}

export default App;
