import React from "react";

function Header() {
    return (
        <header className="header">
            {/* Header content */}
        </header>
    );
}

export default Header;