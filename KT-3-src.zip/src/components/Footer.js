import React from "react";

function Footer() {
    return (
        <footer className="footer">
            {/* Footer content */}
        </footer>
    )
}

export default Footer;