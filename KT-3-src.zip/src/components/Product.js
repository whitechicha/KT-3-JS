import React from 'react';

function Product({ product, onDelete }) {
  const handleDoubleClick = () => {
    onDelete(product.id);
  };

  return (
    <div className="product-card" onDoubleClick={handleDoubleClick}>
      <img src={product.image} alt={product.name} />
      <div className="product-info">
        <h3>{product.name}</h3>
        <p>Price: {product.price}</p>
        <Stars rating={product.rating} />
      </div>
    </div>
  );
}

export default Product;